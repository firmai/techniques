# econ457
ECON457 2018

Textbook: Applied Computational Economics and Finance



Miranda and Fackler's CompEcon toolbox:

http://www4.ncsu.edu/%7Epfackler/compecon/toolbox.html

Julia versions of the CompEcon routines by Miranda and Fackler.

https://github.com/QuantEcon/CompEcon.jl

A Python version of Miranda and Fackler's CompEcon toolbox

https://github.com/randall-romero/CompEcon-python


QuantEcon:


Julia implementation of QuantEcon routines

http://quantecon.org/julia_index.html


Tutorial:

https://software-carpentry.org/lessons/


Environment:

The first programming environment that we will use will be the Cloud9 IDE for both Python and C++.

https://cloud.sagemath.com/

https://c9.io/login?redirect=%2Fnew

https://www.juliabox.com

http://uvic.syzygy.ca/



Reference:

https://github.com/hahnicity/ace

https://github.com/randall-romero/CompEcon-python

https://github.com/broughtj/Fin5350

https://broughtj.github.io/Fin6320/syllabus.html
