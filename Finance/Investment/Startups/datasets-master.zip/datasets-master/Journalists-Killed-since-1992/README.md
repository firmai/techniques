This datasets contains the original data by the Commitee to Protect Journalists. 
The CPJ, with its amazing research work, is tracking killings of journalists (since 1992) and media workers (since 2003) around the globe.
The Journalists.csv file contains [CPJ's original dataset](http://www.cpj.org/killed/) and additional information, like images and short event description, retrived from the individual profiles of each journalist/media worker.
All entries contain the link to the CPJ page where the information comes from.
The data has also been cleaned for unconsistencies, especially in terms of spelling of countries, nationalities and news organizations.
If you think you've spotted any mistakes, please give a shout :-)

The data is by CPJ, and therefore governed by their licence. Refer to [their website](http://www.cpj.org/killed) for information.
