Cleaned and machine readable spreadsheets from data on the [2014 Global Gender Gap Index by the World Economic Forum](http://reports.weforum.org/global-gender-gap-report-2014/).
