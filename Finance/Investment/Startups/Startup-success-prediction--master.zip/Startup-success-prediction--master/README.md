# Startup-success-prediction-
The aim of this project is to create prediction system for startup success or failure. The dataset is taken from crowdanalytics website. We are using R programming language for this project. 
