# Customer Analytics iPython Notebook
See http://kpei.me/blog/?p=921
