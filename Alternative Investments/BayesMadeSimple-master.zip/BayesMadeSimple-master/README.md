This repo contains code for my tutorial, Bayesian Statistics Made Simple.

Here is [the website with more information, installation instructions, etc.](https://sites.google.com/site/simplebayes/)

Launch these noteboooks in your browser: [![Binder](https://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/AllenDowney/BayesMadeSimple/master)
