Jupyter Notebooks for Springer book [Python for Probability, Statistics, and Machine Learning](https://www.springer.com/fr/book/9783319307152)

![Draft cover](./python_for_probability_statistics_and_machine_learning.jpg)

