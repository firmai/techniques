Readme for EmpiricalFinance/jl
==============================

Data used in EmpiricalFinance, taken from internet sources (see lecture notes for detailed references).