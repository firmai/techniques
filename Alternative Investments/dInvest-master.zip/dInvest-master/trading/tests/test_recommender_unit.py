#from recommender.InvestHandler import getSectors
#from web3 import Web3

#class TestInvestHandler:
#    def test_get_sectors(self):
#        sectors = getSectors()
#        assert sectors
