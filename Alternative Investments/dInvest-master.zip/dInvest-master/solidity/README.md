## dApp

### Setup
Install ethereumjs-testrpc using `sudo npm install -g ethereumjs-testrpc`

Install truffle by `sudo npm install -g truffle`

Follow this https://medium.com/zeppelin-blog/the-hitchhikers-guide-to-smart-contracts-in-ethereum-848f08001f05#.hk8dwik30
