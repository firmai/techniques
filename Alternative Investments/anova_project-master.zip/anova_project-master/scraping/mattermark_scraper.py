from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import os
import time
import pandas as pd

dir_path = os.path.dirname(os.path.realpath(__file__))

# Fill in your details here to be posted to the login form.
payload = {
    'inUserName': 'aset8333@uni.sydney.edu.au',
    'inUserPass': 'Qwertyuiop123!'
}

base_url = 'https://mattermark.com/app/data?operator[0]=interested%09!%3D%090&sortBy=cached_growth_score&sortDirection=desc&score_mobile_downloads=1&score_twitter_mentions=1'
login_url = 'https://mattermark.com/app/'

options = webdriver.ChromeOptions()
options.add_experimental_option("prefs", {
  "download.default_directory": dir_path+"/exits_csv",
  "download.prompt_for_download": False,
  "download.directory_upgrade": True,
  "safebrowsing.enabled": True
})
browser = webdriver.Chrome(chrome_options=options)
# Log in to Funderbeam
browser.get(login_url)
time.sleep(5)
browser.find_element_by_id('email').send_keys(payload['inUserName'])
time.sleep(2)
browser.find_element_by_id('password').send_keys(payload['inUserPass']+'\n')
time.sleep(5)

# Scrape investors page
browser.get(base_url)

headers = ['Name','Growth Score','Mindshare Score','Employee Count','Employee Growth Last Month','Employee Growth Last 6 Months','Monthly Uniques Month Over Month Growth','Stage','Total Funding','Last Funding','Last Funding Amount','Location','Revenue']
data = pd.DataFrame(columns=headers)

try:
    element = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.XPATH, '//*[@id="js-main-view-wrap"]/div/main/div[1]/div/div/button'))
    )
    element.click()
except:
    print('Timeout waiting for search to return results')
while True:
    soup = BeautifulSoup(browser.page_source, 'html.parser')
    #table = soup.find('div', {'class': 'tbody-group'})
    table = soup.find('tbody')
    children = table.contents
    for child in children:
        if child == ' ':
            continue
        row = []
        i=0
        for col in child.contents[1:]:
            if col == ' ':
                continue

            row.append(col.text)
        df_row = pd.DataFrame([row],columns=headers)
        data = data.append(df_row, ignore_index=True)
    print(data)
    data = data.drop_duplicates()
    data.to_csv('mattermark.csv')
    browser.implicitly_wait(4)
    # Need to fix pagination
    browser.find_element_by_class_name('paginate_button next').click()
    browser.implicitly_wait(4)
    '''
    try:
        element = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, 'grid-row'))
        )
    except:
        print('Timeout waiting for search to return results')'''
    #print(data)