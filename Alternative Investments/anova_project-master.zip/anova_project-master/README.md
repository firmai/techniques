<h2> Welcome to the ANOVA VC Project team! </h2>

The project aims to test the potential value that automation can bring to the VC industry.We aim to utilise machine learning to assist in sourcing deals, an important aspect of growing the firm’s portfolio.

By drawing data to complement our understanding of the startup ecosystem and what makes them thrive, investors can locate potential deals faster than other competitors and understand what startups require financially and strategically based on profiling similar ventures in other regions.

This project aims to prototype data science solutions that are  able to detect and flag interesting investment opportunities to a VC firm. Information is obtained from various sources such as the major news sources and is extracted and evaluted against a model that measures its potential for growth.

Please see project scope for a more details.


```
The ANOVA Team
```
