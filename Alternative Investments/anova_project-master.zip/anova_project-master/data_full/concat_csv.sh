#!/usr/bin/env bash

NAME=$1
OUTPUT="output2.csv"

read TEST

# This adds the header to the output csv
head -1 "$(find . -name ${NAME} | head -1)" > "hello.csv"

# This appends all csv file data sans header
find . -name ${NAME} -print0 |
    while IFS= read -r -d $'\0' filename; do
        sed 1d "$filename" >> "hello.csv"
    done

# Rename our vc list of names csv
# mv $(find . -name 'investors-*.csv' -print0) investor_list.csv
