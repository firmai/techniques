# -*- coding: utf-8 -*-
"""
Created on Wed Aug  2 16:42:04 2017

@author: Christopher
"""
import pandas as pd

totret = pd.read_pickle('totret')
icm = pd.read_pickle('icm')
dividends = pd.read_pickle('dividends')
dividends2 = pd.read_pickle('dividends2')
investmentuniverse = pd.read_pickle('investmentuniverse')
rf = pd.read_pickle('rf')
df = pd.read_pickle('df')
fama = pd.read_pickle('fama')
DoDportfolios = pd.read_pickle('DoDportfolios')
