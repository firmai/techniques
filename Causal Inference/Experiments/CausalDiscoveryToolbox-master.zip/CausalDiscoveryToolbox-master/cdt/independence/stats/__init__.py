from .all_types import AdjMI, NormMI
from .numerical import (PearsonCorrelation, SpearmanCorrelation, KendallTau, NormalizedHSIC, MIRegression)