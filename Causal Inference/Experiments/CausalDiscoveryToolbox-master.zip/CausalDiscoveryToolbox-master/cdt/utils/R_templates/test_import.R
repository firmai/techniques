# Code to test the import of the 'bnlearn' package.
# ToDo: Try to install if not available.
result = library("{package}")
