These files are for testing the methods and functions in CausalImpact
The nose testing package is required for all tests:

The simplest way to run the tests is to import CausalImpact and run the test() function.

```python
>>> import causalimpact
>>> causalimpact.test()
```
